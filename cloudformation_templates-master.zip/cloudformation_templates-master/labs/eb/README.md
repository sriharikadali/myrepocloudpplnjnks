# AWS Elastic Beanstalk Solutions Templates

## Purpose

Collection of AWS Elastic Beanstalk Solution CloudFormation Templates.
