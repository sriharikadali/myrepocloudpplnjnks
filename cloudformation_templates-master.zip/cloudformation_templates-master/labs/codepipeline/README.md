# AWS CodePipeline Solutions Templates

## Purpose

Collection of AWS CodePipeline Solution CloudFormation Templates.
