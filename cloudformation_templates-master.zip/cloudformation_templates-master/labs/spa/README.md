# Single-Page Application Pipeline 

## Purpose

CloudFormation template to deploy a single-page app to S3 bucket for website hosting

