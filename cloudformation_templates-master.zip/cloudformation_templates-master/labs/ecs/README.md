# ECS Solutions Templates

## Purpose

Collection of EC2 Container Service Solution Templates.
