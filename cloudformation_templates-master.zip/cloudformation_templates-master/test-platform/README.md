# Stelligent CloudFormation Templates

## Purpose
Empty Folder for creating test-platform resources